// import React from 'react';
// import { render } from 'react-dom';
import Reviews from './components/App.jsx';

// render(
//   <App />,
//   document.getElementById('app')
// );

window.Reviews = Reviews;